import {Component} from '@angular/core';
@Component({
    selector : 'upperbar-status',
    templateUrl : './upperstatusbar.componenet.html'
})
export class UpperStatusBarComponent{

}