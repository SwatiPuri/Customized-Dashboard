export interface ISample{
    userId : number,
    id : number,
    title : String,
    body : String 
}