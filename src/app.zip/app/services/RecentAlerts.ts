export interface RecentAlerts{
    

}