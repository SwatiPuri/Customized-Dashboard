export interface IGPSState{
    number_of_satellites : number,
    quality : number,
    fix_type : string,
    hdop:number,
    pdop:number
 }

 