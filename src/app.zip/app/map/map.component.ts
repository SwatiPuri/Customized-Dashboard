import {Component} from '@angular/core';
@Component({
    selector : 'map',
    'templateUrl' : './map.componenet.html',
    styleUrls: ['./map.component.css']
})
export class MapComponent{

}
